from setuptools import setup

setup(  name = "fastxpy",
        version = "1.0.0a2",
        description = "fastx functions",
        url = "https://github.com/mustafa-guler/fastpy",
        author = "Mustafa Guler",
        packages = ["fastxpy"],
        zip_safe = False)

